package com.csc483.assignment.test;

import com.csc483.assignment.sorting.SortingAlgorithms;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Arrays;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 tests for {@link SortingAlgorithms}.
 *
 * <p>All three sorting algorithms are verified against the same set of
 * test cases using a parameterized test approach, ensuring equivalence
 * of results and correctness on edge cases.
 *
 * @author  [Student Name]
 * @version 1.0
 */
@DisplayName("Sorting Algorithm Tests")
class SortingTest {

    private SortingAlgorithms sorter;

    @BeforeEach
    void setUp() {
        sorter = new SortingAlgorithms();
    }

    // -----------------------------------------------------------------------
    // Algorithm provider for parameterized tests
    // -----------------------------------------------------------------------

    /**
     * Provides algorithm names used as parameter to parameterized tests.
     */
    static Stream<String> algorithmNames() {
        return Stream.of("Insertion", "Merge", "Quick");
    }

    // -----------------------------------------------------------------------
    // Helper: dispatch sorting by algorithm name
    // -----------------------------------------------------------------------

    private void sort(String algo, int[] arr) {
        switch (algo) {
            case "Insertion": sorter.insertionSort(arr); break;
            case "Merge":     sorter.mergeSort(arr);     break;
            case "Quick":     sorter.quickSort(arr);     break;
            default: throw new IllegalArgumentException("Unknown: " + algo);
        }
    }

    // -----------------------------------------------------------------------
    // Parameterized correctness tests
    // -----------------------------------------------------------------------

    @ParameterizedTest(name = "{0} Sort – random array")
    @MethodSource("algorithmNames")
    void sort_randomArray_isCorrect(String algo) {
        int[] arr      = { 5, 3, 8, 1, 9, 2, 7, 4, 6, 0 };
        int[] expected = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        sort(algo, arr);
        assertArrayEquals(expected, arr);
    }

    @ParameterizedTest(name = "{0} Sort – already sorted")
    @MethodSource("algorithmNames")
    void sort_alreadySorted_isCorrect(String algo) {
        int[] arr      = { 1, 2, 3, 4, 5 };
        int[] expected = { 1, 2, 3, 4, 5 };
        sort(algo, arr);
        assertArrayEquals(expected, arr);
    }

    @ParameterizedTest(name = "{0} Sort – reverse sorted")
    @MethodSource("algorithmNames")
    void sort_reverseSorted_isCorrect(String algo) {
        int[] arr      = { 9, 7, 5, 3, 1 };
        int[] expected = { 1, 3, 5, 7, 9 };
        sort(algo, arr);
        assertArrayEquals(expected, arr);
    }

    @ParameterizedTest(name = "{0} Sort – all duplicates")
    @MethodSource("algorithmNames")
    void sort_allDuplicates_isCorrect(String algo) {
        int[] arr      = { 4, 4, 4, 4, 4 };
        int[] expected = { 4, 4, 4, 4, 4 };
        sort(algo, arr);
        assertArrayEquals(expected, arr);
    }

    @ParameterizedTest(name = "{0} Sort – single element")
    @MethodSource("algorithmNames")
    void sort_singleElement_unchanged(String algo) {
        int[] arr = { 42 };
        sort(algo, arr);
        assertArrayEquals(new int[]{ 42 }, arr);
    }

    @ParameterizedTest(name = "{0} Sort – empty array")
    @MethodSource("algorithmNames")
    void sort_emptyArray_unchanged(String algo) {
        int[] arr = {};
        sort(algo, arr);
        assertArrayEquals(new int[]{}, arr);
    }

    @ParameterizedTest(name = "{0} Sort – null array does not throw")
    @MethodSource("algorithmNames")
    void sort_nullArray_doesNotThrow(String algo) {
        assertDoesNotThrow(() -> sort(algo, null));
    }

    @ParameterizedTest(name = "{0} Sort – negative numbers")
    @MethodSource("algorithmNames")
    void sort_negativeNumbers_isCorrect(String algo) {
        int[] arr      = { -3, 5, -1, 0, 2, -10, 8 };
        int[] expected = { -10, -3, -1, 0, 2, 5, 8 };
        sort(algo, arr);
        assertArrayEquals(expected, arr);
    }

    @ParameterizedTest(name = "{0} Sort – two elements swapped")
    @MethodSource("algorithmNames")
    void sort_twoElements_swapped(String algo) {
        int[] arr      = { 7, 3 };
        int[] expected = { 3, 7 };
        sort(algo, arr);
        assertArrayEquals(expected, arr);
    }

    @ParameterizedTest(name = "{0} Sort – large array is sorted")
    @MethodSource("algorithmNames")
    void sort_largeArray_isCorrect(String algo) {
        int n   = 10_000;
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = n - i;  // reverse sorted

        int[] expected = SortingAlgorithms.copy(arr);
        Arrays.sort(expected);                          // Java's sort as oracle

        sort(algo, arr);
        assertArrayEquals(expected, arr);
    }

    // -----------------------------------------------------------------------
    // Counter sanity checks
    // -----------------------------------------------------------------------

    @ParameterizedTest(name = "{0} Sort – comparison count > 0 for n > 1")
    @MethodSource("algorithmNames")
    void sort_comparisonCount_positive(String algo) {
        int[] arr = { 3, 1, 4, 1, 5, 9, 2, 6 };
        sort(algo, arr);
        assertTrue(sorter.getComparisons() > 0,
                algo + " should record > 0 comparisons");
    }

    @Test
    @DisplayName("Insertion Sort – best case comparisons equals n-1 for sorted input")
    void insertionSort_bestCase_comparisons() {
        int n = 10;
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = i;   // already sorted

        sorter.insertionSort(arr);
        // Each inner loop runs exactly once (one comparison per outer iteration)
        assertEquals(n - 1, sorter.getComparisons());
    }
}
