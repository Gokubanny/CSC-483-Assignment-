package com.csc483.assignment.test;

import com.csc483.assignment.search.HybridSearchIndex;
import com.csc483.assignment.search.Product;
import com.csc483.assignment.search.SearchAlgorithms;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 tests for {@link SearchAlgorithms} and {@link HybridSearchIndex}.
 *
 * <p>Covers: normal cases, edge cases (empty array, null inputs, duplicates),
 * and boundary values for sequential search, binary search, and the hybrid
 * index.
 *
 * @author  [Student Name]
 * @version 1.0
 */
@DisplayName("Search Algorithm Tests")
class SearchTest {

    private SearchAlgorithms searcher;
    private Product[] sortedProducts;     // sorted by ID: 10, 20, 30, 40, 50
    private Product[] unsortedProducts;  // intentionally unsorted

    @BeforeEach
    void setUp() {
        searcher = new SearchAlgorithms();

        sortedProducts = new Product[]{
            new Product(10, "Alpha",   "Laptop",  999.99, 5),
            new Product(20, "Beta",    "Phone",   499.00, 10),
            new Product(30, "Gamma",   "Tablet",  349.00, 8),
            new Product(40, "Delta",   "Monitor", 279.00, 3),
            new Product(50, "Epsilon", "Mouse",    29.99, 20)
        };

        unsortedProducts = new Product[]{
            new Product(30, "Gamma",   "Tablet",  349.00, 8),
            new Product(10, "Alpha",   "Laptop",  999.99, 5),
            new Product(50, "Epsilon", "Mouse",    29.99, 20),
            new Product(20, "Beta",    "Phone",   499.00, 10),
            new Product(40, "Delta",   "Monitor", 279.00, 3)
        };
    }

    // -----------------------------------------------------------------------
    // Sequential Search – Normal cases
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Sequential search: finds first element (best case)")
    void seqSearch_bestCase_findsFirst() {
        Product result = searcher.sequentialSearchById(unsortedProducts, 30);
        assertNotNull(result);
        assertEquals(30, result.getProductId());
        assertEquals(1, searcher.getLastComparisonCount());
    }

    @Test
    @DisplayName("Sequential search: finds middle element")
    void seqSearch_findsMiddle() {
        Product result = searcher.sequentialSearchById(unsortedProducts, 50);
        assertNotNull(result);
        assertEquals(50, result.getProductId());
        assertEquals(3, searcher.getLastComparisonCount());
    }

    @Test
    @DisplayName("Sequential search: ID not found returns null (worst case)")
    void seqSearch_worstCase_notFound() {
        Product result = searcher.sequentialSearchById(unsortedProducts, 999);
        assertNull(result);
        assertEquals(unsortedProducts.length, searcher.getLastComparisonCount());
    }

    // -----------------------------------------------------------------------
    // Sequential Search – Edge cases
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Sequential search: null array returns null")
    void seqSearch_nullArray_returnsNull() {
        assertNull(searcher.sequentialSearchById(null, 10));
    }

    @Test
    @DisplayName("Sequential search: empty array returns null")
    void seqSearch_emptyArray_returnsNull() {
        assertNull(searcher.sequentialSearchById(new Product[0], 10));
    }

    // -----------------------------------------------------------------------
    // Binary Search – Normal cases
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Binary search: finds first element")
    void binSearch_findsFirst() {
        Product result = searcher.binarySearchById(sortedProducts, 10);
        assertNotNull(result);
        assertEquals(10, result.getProductId());
    }

    @Test
    @DisplayName("Binary search: finds last element")
    void binSearch_findsLast() {
        Product result = searcher.binarySearchById(sortedProducts, 50);
        assertNotNull(result);
        assertEquals(50, result.getProductId());
    }

    @Test
    @DisplayName("Binary search: finds middle element (best case)")
    void binSearch_findsMiddle_bestCase() {
        Product result = searcher.binarySearchById(sortedProducts, 30);
        assertNotNull(result);
        assertEquals(30, result.getProductId());
        assertEquals(1, searcher.getLastComparisonCount());
    }

    @Test
    @DisplayName("Binary search: ID not found returns null")
    void binSearch_notFound_returnsNull() {
        assertNull(searcher.binarySearchById(sortedProducts, 999));
    }

    // -----------------------------------------------------------------------
    // Binary Search – Edge cases
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Binary search: null array returns null")
    void binSearch_nullArray_returnsNull() {
        assertNull(searcher.binarySearchById(null, 10));
    }

    @Test
    @DisplayName("Binary search: empty array returns null")
    void binSearch_emptyArray_returnsNull() {
        assertNull(searcher.binarySearchById(new Product[0], 10));
    }

    @Test
    @DisplayName("Binary search: single-element array – match")
    void binSearch_singleElement_match() {
        Product[] arr = { new Product(99, "Solo", "Misc", 1.0, 1) };
        Product result = searcher.binarySearchById(arr, 99);
        assertNotNull(result);
        assertEquals(99, result.getProductId());
    }

    @Test
    @DisplayName("Binary search: single-element array – no match")
    void binSearch_singleElement_noMatch() {
        Product[] arr = { new Product(99, "Solo", "Misc", 1.0, 1) };
        assertNull(searcher.binarySearchById(arr, 1));
    }

    // -----------------------------------------------------------------------
    // Search by Name
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Name search: case-insensitive match")
    void nameSearch_caseInsensitive() {
        Product result = searcher.searchByName(unsortedProducts, "GAMMA");
        assertNotNull(result);
        assertEquals("Gamma", result.getProductName());
    }

    @Test
    @DisplayName("Name search: not found returns null")
    void nameSearch_notFound_returnsNull() {
        assertNull(searcher.searchByName(unsortedProducts, "Zeta"));
    }

    @Test
    @DisplayName("Name search: null name returns null")
    void nameSearch_nullName_returnsNull() {
        assertNull(searcher.searchByName(unsortedProducts, null));
    }

    // -----------------------------------------------------------------------
    // Hybrid Search Index
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Hybrid index: search by ID")
    void hybridIndex_searchById() {
        HybridSearchIndex index = new HybridSearchIndex(unsortedProducts);
        Product result = index.searchById(20);
        assertNotNull(result);
        assertEquals(20, result.getProductId());
    }

    @Test
    @DisplayName("Hybrid index: search by name")
    void hybridIndex_searchByName() {
        HybridSearchIndex index = new HybridSearchIndex(unsortedProducts);
        Product result = index.searchByName("delta");
        assertNotNull(result);
        assertEquals(40, result.getProductId());
    }

    @Test
    @DisplayName("Hybrid index: add product and find it")
    void hybridIndex_addProduct_thenFind() {
        HybridSearchIndex index = new HybridSearchIndex(unsortedProducts);
        Product newProduct = new Product(25, "Zeta", "SSD", 89.99, 15);
        index.addProduct(newProduct);

        // Should be found by ID
        Product byId = index.searchById(25);
        assertNotNull(byId);
        assertEquals("Zeta", byId.getProductName());

        // Should be found by name
        Product byName = index.searchByName("Zeta");
        assertNotNull(byName);
        assertEquals(25, byName.getProductId());

        // Size should have increased
        assertEquals(6, index.size());
    }

    @Test
    @DisplayName("Hybrid index: sorted order maintained after addProduct")
    void hybridIndex_sortedOrderMaintained() {
        HybridSearchIndex index = new HybridSearchIndex(unsortedProducts);
        index.addProduct(new Product(5,  "Pre-Alpha", "Misc", 9.99,  1));
        index.addProduct(new Product(55, "Zeta",      "Misc", 9.99,  1));
        index.addProduct(new Product(25, "MidRange",  "Misc", 49.99, 5));

        Product[] sorted = index.getSortedProducts();
        for (int i = 0; i < sorted.length - 1; i++) {
            assertTrue(sorted[i].getProductId() < sorted[i + 1].getProductId(),
                    "Array is not sorted at index " + i);
        }
    }

    @Test
    @DisplayName("Hybrid index: duplicate ID throws IllegalArgumentException")
    void hybridIndex_duplicateId_throwsException() {
        HybridSearchIndex index = new HybridSearchIndex(unsortedProducts);
        Product duplicate = new Product(10, "Duplicate", "Test", 1.0, 1);
        assertThrows(IllegalArgumentException.class, () -> index.addProduct(duplicate));
    }

    // -----------------------------------------------------------------------
    // Product class validation
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Product: negative ID throws IllegalArgumentException")
    void product_negativeId_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> new Product(-1, "Bad", "Cat", 1.0, 0));
    }

    @Test
    @DisplayName("Product: negative price throws IllegalArgumentException")
    void product_negativePrice_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> new Product(1, "OK", "Cat", -5.0, 0));
    }

    @Test
    @DisplayName("Product: blank name throws IllegalArgumentException")
    void product_blankName_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> new Product(1, "  ", "Cat", 1.0, 0));
    }

    @Test
    @DisplayName("Product: compareTo is consistent with ID ordering")
    void product_compareTo_consistency() {
        Product p1 = new Product(10, "A", "C", 1.0, 1);
        Product p2 = new Product(20, "B", "C", 2.0, 1);
        assertTrue(p1.compareTo(p2) < 0);
        assertTrue(p2.compareTo(p1) > 0);
        assertEquals(0, p1.compareTo(new Product(10, "X", "Y", 9.0, 9)));
    }
}
