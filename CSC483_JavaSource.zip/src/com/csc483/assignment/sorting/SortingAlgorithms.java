package com.csc483.assignment.sorting;

/**
 * Implementations of three sorting algorithms studied in CSC 483.1:
 * Insertion Sort, Merge Sort, and Quick Sort.
 *
 * <p>Each method sorts an {@code int[]} array in ascending order <em>in-place</em>
 * (except Merge Sort which requires O(n) auxiliary space). Comparison and swap
 * counters are maintained per-sort and accessible after each call.
 *
 * <h3>Complexity Summary</h3>
 * <table border="1">
 *   <tr><th>Algorithm</th><th>Best</th><th>Average</th><th>Worst</th>
 *       <th>Space</th><th>Stable?</th></tr>
 *   <tr><td>Insertion Sort</td><td>O(n)</td><td>O(n^2)</td><td>O(n^2)</td>
 *       <td>O(1)</td><td>Yes</td></tr>
 *   <tr><td>Merge Sort</td><td>O(n log n)</td><td>O(n log n)</td><td>O(n log n)</td>
 *       <td>O(n)</td><td>Yes</td></tr>
 *   <tr><td>Quick Sort</td><td>O(n log n)</td><td>O(n log n)</td><td>O(n^2)</td>
 *       <td>O(log n)</td><td>No</td></tr>
 * </table>
 *
 * @author  [Student Name]
 * @version 1.0
 */
public class SortingAlgorithms {

    // -----------------------------------------------------------------------
    // Instrumentation counters
    // -----------------------------------------------------------------------

    private long comparisons;
    private long swaps;

    /** @return number of comparisons made during the last sort call */
    public long getComparisons() { return comparisons; }

    /** @return number of swaps / assignments made during the last sort call */
    public long getSwaps()       { return swaps; }

    // -----------------------------------------------------------------------
    // 1. Insertion Sort  –  O(n^2) average/worst, O(n) best
    // -----------------------------------------------------------------------

    /**
     * Sorts {@code arr} using insertion sort.
     *
     * <p>Insertion sort builds a sorted sub-array one element at a time by
     * repeatedly taking the next unsorted element and inserting it into its
     * correct position within the already-sorted portion.
     *
     * <p><b>When to use:</b> small arrays (n &lt; ~50), nearly-sorted data,
     * or when simplicity and in-place/stable behaviour is required.
     *
     * @param arr the integer array to sort (modified in place)
     */
    public void insertionSort(int[] arr) {
        if (arr == null || arr.length <= 1) return;
        comparisons = 0;
        swaps = 0;

        for (int i = 1; i < arr.length; i++) {
            int key = arr[i];       // element to be inserted
            int j = i - 1;

            // Shift elements that are greater than key one position to the right
            while (j >= 0) {
                comparisons++;
                if (arr[j] > key) {
                    arr[j + 1] = arr[j];   // shift right
                    swaps++;
                    j--;
                } else {
                    break;
                }
            }
            arr[j + 1] = key;              // place key in correct position
            if (j + 1 != i) swaps++;      // only count if a move was made
        }
    }

    // -----------------------------------------------------------------------
    // 2. Merge Sort  –  O(n log n) all cases, O(n) space
    // -----------------------------------------------------------------------

    /**
     * Sorts {@code arr} using merge sort.
     *
     * <p>Merge sort divides the array into two halves, recursively sorts each
     * half, and then merges the two sorted halves. It guarantees O(n log n)
     * in all cases at the cost of O(n) auxiliary space.
     *
     * <p><b>When to use:</b> when stable sort is required, when guaranteed
     * O(n log n) worst-case is needed, or for sorting linked lists.
     *
     * @param arr the integer array to sort (modified in place)
     */
    public void mergeSort(int[] arr) {
        if (arr == null || arr.length <= 1) return;
        comparisons = 0;
        swaps = 0;
        mergeSortHelper(arr, 0, arr.length - 1);
    }

    /** Recursive helper: sorts arr[low..high] inclusive. */
    private void mergeSortHelper(int[] arr, int low, int high) {
        if (low >= high) return;

        int mid = low + (high - low) / 2;
        mergeSortHelper(arr, low, mid);
        mergeSortHelper(arr, mid + 1, high);
        merge(arr, low, mid, high);
    }

    /**
     * Merges two sorted sub-arrays arr[low..mid] and arr[mid+1..high].
     * Uses a temporary array of size (high - low + 1).
     */
    private void merge(int[] arr, int low, int mid, int high) {
        int[] temp = new int[high - low + 1];
        int i = low, j = mid + 1, k = 0;

        while (i <= mid && j <= high) {
            comparisons++;
            if (arr[i] <= arr[j]) {        // stable: equal elements from left half first
                temp[k++] = arr[i++];
            } else {
                temp[k++] = arr[j++];
                swaps++;                   // counts each "merge move" as an assignment
            }
        }

        while (i <= mid)  { temp[k++] = arr[i++]; swaps++; }
        while (j <= high) { temp[k++] = arr[j++]; swaps++; }

        // Copy back to original array
        for (int x = 0; x < temp.length; x++) {
            arr[low + x] = temp[x];
        }
    }

    // -----------------------------------------------------------------------
    // 3. Quick Sort  –  O(n log n) avg, O(n^2) worst, O(log n) space
    // -----------------------------------------------------------------------

    /**
     * Sorts {@code arr} using quick sort with a median-of-three pivot strategy.
     *
     * <p>Quick sort selects a pivot element, partitions the array around it
     * (elements &lt; pivot go left, elements &gt; pivot go right), and
     * recursively sorts each partition. Median-of-three pivot selection
     * reduces the probability of O(n^2) worst-case on sorted/nearly-sorted data.
     *
     * <p><b>When to use:</b> general-purpose sorting where average-case
     * performance matters and in-place behavior is preferred.
     *
     * @param arr the integer array to sort (modified in place)
     */
    public void quickSort(int[] arr) {
        if (arr == null || arr.length <= 1) return;
        comparisons = 0;
        swaps = 0;
        quickSortHelper(arr, 0, arr.length - 1);
    }

    /** Recursive helper: sorts arr[low..high] inclusive. */
    private void quickSortHelper(int[] arr, int low, int high) {
        if (low >= high) return;

        // Use insertion sort for small sub-arrays (optimisation)
        if (high - low < 10) {
            insertionSortRange(arr, low, high);
            return;
        }

        int pivotIndex = partition(arr, low, high);
        quickSortHelper(arr, low, pivotIndex - 1);
        quickSortHelper(arr, pivotIndex + 1, high);
    }

    /**
     * Partitions arr[low..high] using median-of-three pivot.
     *
     * @return the final index of the pivot element
     */
    private int partition(int[] arr, int low, int high) {
        // Median-of-three: sort arr[low], arr[mid], arr[high], use arr[mid] as pivot
        int mid = low + (high - low) / 2;
        medianOfThree(arr, low, mid, high);
        int pivot = arr[mid];
        swap(arr, mid, high - 1);          // move pivot out of the way

        int i = low, j = high - 1;

        while (true) {
            comparisons++;
            while (i < high && arr[++i] < pivot) { comparisons++; }
            comparisons++;
            while (j > low  && arr[--j] > pivot) { comparisons++; }
            if (i >= j) break;
            swap(arr, i, j);
        }

        swap(arr, i, high - 1);            // restore pivot
        return i;
    }

    /** Orders arr[a], arr[b], arr[c] so arr[b] is the median. */
    private void medianOfThree(int[] arr, int a, int b, int c) {
        comparisons++;
        if (arr[a] > arr[b]) { swap(arr, a, b); }
        comparisons++;
        if (arr[b] > arr[c]) { swap(arr, b, c); }
        comparisons++;
        if (arr[a] > arr[b]) { swap(arr, a, b); }
    }

    /** Insertion sort for arr[low..high] (used for small sub-arrays). */
    private void insertionSortRange(int[] arr, int low, int high) {
        for (int i = low + 1; i <= high; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= low) {
                comparisons++;
                if (arr[j] > key) { arr[j + 1] = arr[j]; swaps++; j--; }
                else break;
            }
            arr[j + 1] = key;
        }
    }

    /** Swaps arr[i] and arr[j]. */
    private void swap(int[] arr, int i, int j) {
        if (i == j) return;
        int tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
        swaps++;
    }

    // -----------------------------------------------------------------------
    // Utility: copy array (used by benchmarks to reset between runs)
    // -----------------------------------------------------------------------

    /**
     * Returns a fresh copy of {@code arr} so benchmark runs start from
     * the same unsorted state.
     *
     * @param arr source array
     * @return independent copy
     */
    public static int[] copy(int[] arr) {
        if (arr == null) return null;
        int[] out = new int[arr.length];
        System.arraycopy(arr, 0, out, 0, arr.length);
        return out;
    }
}
