package com.csc483.assignment.sorting;

import java.util.Arrays;
import java.util.Random;

/**
 * Empirical benchmarking driver for Question 2, Part C.
 *
 * <p>Generates five types of datasets at four sizes, runs Insertion Sort,
 * Merge Sort, and Quick Sort on each, and prints a formatted comparison table
 * with execution time, comparison count, and swap count.
 *
 * <h3>How to compile and run</h3>
 * <pre>
 *   javac -d out src/com/csc483/assignment/sorting/*.java
 *   java  -cp out com.csc483.assignment.sorting.BenchmarkRunner
 * </pre>
 *
 * @author  [Student Name]
 * @version 1.0
 */
public class BenchmarkRunner {

    /** Input sizes to test. */
    private static final int[] SIZES = { 100, 1_000, 10_000, 100_000 };

    /** Number of repeated runs whose times are averaged. */
    private static final int RUNS = 5;

    /** Fixed random seed for reproducibility. */
    private static final long SEED = 42L;

    /** Number of distinct values in the "many duplicates" dataset. */
    private static final int DISTINCT_VALUES = 10;

    /** Fraction of positions that are random in the "nearly sorted" dataset. */
    private static final double NEARLY_SORTED_FRACTION = 0.10;

    public static void main(String[] args) {

        SortingAlgorithms sorter = new SortingAlgorithms();
        String[] dataTypes = { "Random", "Sorted", "Reverse Sorted", "Nearly Sorted", "Many Duplicates" };
        String[] algorithms = { "Insertion", "Merge", "Quick" };

        System.out.println("================================================================");
        System.out.println("   SORTING ALGORITHMS COMPARISON  (avg of " + RUNS + " runs)");
        System.out.println("================================================================");

        for (String dataType : dataTypes) {
            System.out.println("\n--- Data type: " + dataType + " ---");
            System.out.printf("%-12s %-12s %12s %15s %12s%n",
                    "Input Size", "Algorithm", "Time (ms)", "Comparisons", "Swaps");
            System.out.println("-".repeat(65));

            for (int size : SIZES) {
                // Generate the base dataset once per (dataType, size) combo
                int[] baseArr = generateData(dataType, size);

                for (String algo : algorithms) {
                    double[] times  = new double[RUNS];
                    long[]   comps  = new long[RUNS];
                    long[]   swapCt = new long[RUNS];

                    for (int r = 0; r < RUNS; r++) {
                        int[] arr = SortingAlgorithms.copy(baseArr);
                        long start = System.nanoTime();

                        switch (algo) {
                            case "Insertion": sorter.insertionSort(arr); break;
                            case "Merge":     sorter.mergeSort(arr);     break;
                            case "Quick":     sorter.quickSort(arr);     break;
                        }

                        times[r]  = (System.nanoTime() - start) / 1_000_000.0;
                        comps[r]  = sorter.getComparisons();
                        swapCt[r] = sorter.getSwaps();
                    }

                    double avgTime  = mean(times);
                    double avgComp  = mean(comps);
                    double avgSwap  = mean(swapCt);

                    System.out.printf("%-12d %-12s %12.3f %15.0f %12.0f%n",
                            size, algo, avgTime, avgComp, avgSwap);
                }
                System.out.println();
            }
        }

        // ------------------------------------------------------------------ //
        //  Statistical analysis for random data, n = 10,000                  //
        // ------------------------------------------------------------------ //
        System.out.println("\n================================================================");
        System.out.println("   STATISTICAL ANALYSIS: Random data, n = 10,000");
        System.out.println("================================================================");
        System.out.printf("%-12s %10s %10s %10s%n", "Algorithm", "Mean(ms)", "StdDev", "t-stat vs Ins");

        double[] insTimes = collectTimes(sorter, "Random", 10_000, "Insertion", 30);
        double[] mrgTimes = collectTimes(sorter, "Random", 10_000, "Merge",     30);
        double[] qkTimes  = collectTimes(sorter, "Random", 10_000, "Quick",     30);

        System.out.printf("%-12s %10.3f %10.3f %10s%n",
                "Insertion", mean(insTimes), stddev(insTimes), "---");
        System.out.printf("%-12s %10.3f %10.3f %10.3f%n",
                "Merge", mean(mrgTimes), stddev(mrgTimes), tStat(insTimes, mrgTimes));
        System.out.printf("%-12s %10.3f %10.3f %10.3f%n",
                "Quick", mean(qkTimes), stddev(qkTimes), tStat(insTimes, qkTimes));

        System.out.println("\nConclusions:");
        System.out.println("- Quick Sort is fastest on average for random data.");
        System.out.println("- Insertion Sort is competitive only for n < 1,000.");
        System.out.println("- Merge Sort provides consistent performance regardless of data order.");
        System.out.println("- Quick Sort degrades to O(n^2) on sorted data without pivot optimisation.");
        System.out.println("================================================================");
    }

    // -----------------------------------------------------------------------
    // Dataset generators
    // -----------------------------------------------------------------------

    /**
     * Generates an integer array of the requested type and size.
     *
     * @param type one of "Random", "Sorted", "Reverse Sorted",
     *             "Nearly Sorted", "Many Duplicates"
     * @param size number of elements
     * @return the generated array
     */
    static int[] generateData(String type, int size) {
        Random rng = new Random(SEED);
        int[] arr = new int[size];

        switch (type) {
            case "Random":
                for (int i = 0; i < size; i++) arr[i] = rng.nextInt(size * 10);
                break;

            case "Sorted":
                for (int i = 0; i < size; i++) arr[i] = i;
                break;

            case "Reverse Sorted":
                for (int i = 0; i < size; i++) arr[i] = size - i;
                break;

            case "Nearly Sorted":
                for (int i = 0; i < size; i++) arr[i] = i;
                int swapCount = (int) (size * NEARLY_SORTED_FRACTION);
                for (int k = 0; k < swapCount; k++) {
                    int a = rng.nextInt(size), b = rng.nextInt(size);
                    int tmp = arr[a]; arr[a] = arr[b]; arr[b] = tmp;
                }
                break;

            case "Many Duplicates":
                for (int i = 0; i < size; i++) arr[i] = rng.nextInt(DISTINCT_VALUES);
                break;

            default:
                throw new IllegalArgumentException("Unknown data type: " + type);
        }
        return arr;
    }

    // -----------------------------------------------------------------------
    // Statistics helpers
    // -----------------------------------------------------------------------

    /** Collects {@code runs} execution time samples for statistical analysis. */
    private static double[] collectTimes(SortingAlgorithms s, String dataType,
                                         int size, String algo, int runs) {
        double[] times = new double[runs];
        int[] base = generateData(dataType, size);
        for (int r = 0; r < runs; r++) {
            int[] arr = SortingAlgorithms.copy(base);
            long start = System.nanoTime();
            switch (algo) {
                case "Insertion": s.insertionSort(arr); break;
                case "Merge":     s.mergeSort(arr);     break;
                case "Quick":     s.quickSort(arr);     break;
            }
            times[r] = (System.nanoTime() - start) / 1_000_000.0;
        }
        return times;
    }

    private static double mean(double[] a) {
        double sum = 0;
        for (double v : a) sum += v;
        return sum / a.length;
    }

    private static double mean(long[] a) {
        long sum = 0;
        for (long v : a) sum += v;
        return (double) sum / a.length;
    }

    private static double stddev(double[] a) {
        double m = mean(a), sum = 0;
        for (double v : a) sum += (v - m) * (v - m);
        return Math.sqrt(sum / (a.length - 1));
    }

    /**
     * Computes Welch's t-statistic for two independent samples a and b.
     * A large |t| (typically &gt; 2) suggests a statistically significant
     * difference in means.
     */
    private static double tStat(double[] a, double[] b) {
        double mA = mean(a), mB = mean(b);
        double sA = stddev(a), sB = stddev(b);
        double se = Math.sqrt((sA * sA / a.length) + (sB * sB / b.length));
        return se == 0 ? 0 : (mA - mB) / se;
    }
}
