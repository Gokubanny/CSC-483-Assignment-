package com.csc483.assignment.search;

/**
 * Represents a product in the TechMart online electronics store.
 *
 * <p>Each product has a unique integer ID, a name, category, price,
 * and available stock quantity. The natural ordering is by productId,
 * which is required by the binary-search methods in {@link SearchAlgorithms}.
 *
 * @author  [Student Name]
 * @version 1.0
 */
public class Product implements Comparable<Product> {

    /** Unique identifier for this product (1 – 200,000). */
    private int productId;

    /** Human-readable name of the product. */
    private String productName;

    /** Category the product belongs to (e.g. "Laptop", "Phone"). */
    private String category;

    /** Retail price of the product in USD. */
    private double price;

    /** Number of units currently in stock. */
    private int stockQuantity;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Constructs a fully initialised Product.
     *
     * @param productId     unique integer ID
     * @param productName   product name (must not be null or blank)
     * @param category      product category (must not be null or blank)
     * @param price         retail price (must be &gt;= 0)
     * @param stockQuantity units in stock (must be &gt;= 0)
     * @throws IllegalArgumentException if any argument violates the listed constraints
     */
    public Product(int productId, String productName, String category,
                   double price, int stockQuantity) {
        if (productId <= 0)
            throw new IllegalArgumentException("productId must be positive, got: " + productId);
        if (productName == null || productName.isBlank())
            throw new IllegalArgumentException("productName must not be null or blank");
        if (category == null || category.isBlank())
            throw new IllegalArgumentException("category must not be null or blank");
        if (price < 0)
            throw new IllegalArgumentException("price must be >= 0, got: " + price);
        if (stockQuantity < 0)
            throw new IllegalArgumentException("stockQuantity must be >= 0, got: " + stockQuantity);

        this.productId     = productId;
        this.productName   = productName;
        this.category      = category;
        this.price         = price;
        this.stockQuantity = stockQuantity;
    }

    // -----------------------------------------------------------------------
    // Getters & Setters
    // -----------------------------------------------------------------------

    /** @return the unique product ID */
    public int getProductId()           { return productId; }

    /** @return the product name */
    public String getProductName()      { return productName; }

    /** @return the product category */
    public String getCategory()         { return category; }

    /** @return the retail price */
    public double getPrice()            { return price; }

    /** @return the current stock quantity */
    public int getStockQuantity()       { return stockQuantity; }

    /**
     * Updates the stock quantity.
     * @param stockQuantity new quantity (must be &gt;= 0)
     */
    public void setStockQuantity(int stockQuantity) {
        if (stockQuantity < 0)
            throw new IllegalArgumentException("stockQuantity must be >= 0");
        this.stockQuantity = stockQuantity;
    }

    /**
     * Updates the retail price.
     * @param price new price (must be &gt;= 0)
     */
    public void setPrice(double price) {
        if (price < 0)
            throw new IllegalArgumentException("price must be >= 0");
        this.price = price;
    }

    // -----------------------------------------------------------------------
    // Comparable / Object overrides
    // -----------------------------------------------------------------------

    /**
     * Compares products by {@code productId} (ascending).
     * This ordering is required so the sorted array can be searched
     * with {@link SearchAlgorithms#binarySearchById}.
     */
    @Override
    public int compareTo(Product other) {
        return Integer.compare(this.productId, other.productId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Product)) return false;
        return this.productId == ((Product) obj).productId;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(productId);
    }

    @Override
    public String toString() {
        return String.format("Product{id=%d, name='%s', category='%s', price=%.2f, stock=%d}",
                productId, productName, category, price, stockQuantity);
    }
}
