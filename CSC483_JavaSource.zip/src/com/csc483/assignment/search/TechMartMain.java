package com.csc483.assignment.search;

import java.util.Arrays;
import java.util.Random;

/**
 * Main driver for Question 1: TechMart Search Performance Analysis.
 *
 * <p>Generates a dataset of 100,000 random products, measures execution times
 * for sequential and binary search under best, average, and worst-case conditions,
 * and prints a formatted performance comparison table. It also benchmarks the
 * hybrid search index from {@link HybridSearchIndex}.
 *
 * <h3>How to compile and run</h3>
 * <pre>
 *   javac -d out src/com/csc483/assignment/search/*.java
 *   java  -cp out com.csc483.assignment.search.TechMartMain
 * </pre>
 *
 * @author  [Student Name]
 * @version 1.0
 */
public class TechMartMain {

    /** Total number of products to generate for benchmarking. */
    private static final int DATASET_SIZE = 100_000;

    /** Product IDs are randomly chosen from [1, MAX_ID]. */
    private static final int MAX_ID = 200_000;

    /** Number of benchmark repetitions for averaging execution time. */
    private static final int REPETITIONS = 5;

    /** Categories used when generating random products. */
    private static final String[] CATEGORIES = {
        "Laptop", "Phone", "Tablet", "Monitor", "Keyboard",
        "Mouse", "Headphones", "Camera", "Printer", "SSD"
    };

    public static void main(String[] args) {

        // ------------------------------------------------------------------ //
        //  1. Generate dataset                                                //
        // ------------------------------------------------------------------ //
        System.out.println("Generating " + DATASET_SIZE + " random products ...");
        Product[] unsortedProducts = generateProducts(DATASET_SIZE);

        // Sorted copy for binary search
        Product[] sortedProducts = Arrays.copyOf(unsortedProducts, unsortedProducts.length);
        Arrays.sort(sortedProducts);            // uses Product.compareTo (by ID)

        SearchAlgorithms searcher = new SearchAlgorithms();

        // ------------------------------------------------------------------ //
        //  2. Identify test targets                                           //
        // ------------------------------------------------------------------ //
        int bestCaseId   = sortedProducts[0].getProductId();            // position 0
        int avgCaseId    = sortedProducts[DATASET_SIZE / 2].getProductId(); // middle
        int worstCaseId  = -1;                                           // not in array

        // ------------------------------------------------------------------ //
        //  3. Benchmark sequential search                                     //
        // ------------------------------------------------------------------ //
        double seqBest    = measureSeqSearch(searcher, sortedProducts, bestCaseId);
        double seqAvg     = measureSeqSearch(searcher, sortedProducts, avgCaseId);
        double seqWorst   = measureSeqSearch(searcher, sortedProducts, worstCaseId);

        // ------------------------------------------------------------------ //
        //  4. Benchmark binary search                                         //
        // ------------------------------------------------------------------ //
        double binBest    = measureBinSearch(searcher, sortedProducts, bestCaseId);
        double binAvg     = measureBinSearch(searcher, sortedProducts, avgCaseId);
        double binWorst   = measureBinSearch(searcher, sortedProducts, worstCaseId);

        // ------------------------------------------------------------------ //
        //  5. Benchmark hybrid name search                                    //
        // ------------------------------------------------------------------ //
        HybridSearchIndex index = new HybridSearchIndex(sortedProducts);

        String sampleName = sortedProducts[DATASET_SIZE / 2].getProductName();
        double hybridSearchTime = measureHybridNameSearch(index, sampleName);
        double hybridInsertTime = measureHybridInsert(index);

        // ------------------------------------------------------------------ //
        //  6. Print results                                                   //
        // ------------------------------------------------------------------ //
        double improvement = seqAvg > 0 ? seqAvg / binAvg : 0;

        System.out.println();
        System.out.println("================================================================");
        System.out.println("   TECHMART SEARCH PERFORMANCE ANALYSIS (n = " + DATASET_SIZE + " products)");
        System.out.println("================================================================");
        System.out.printf("SEQUENTIAL SEARCH:%n");
        System.out.printf("  Best Case  (ID found at position 0): %10.3f ms%n", seqBest);
        System.out.printf("  Average Case (random ID):            %10.3f ms%n", seqAvg);
        System.out.printf("  Worst Case (ID not found):           %10.3f ms%n", seqWorst);
        System.out.println();
        System.out.printf("BINARY SEARCH:%n");
        System.out.printf("  Best Case  (ID at middle):           %10.3f ms%n", binBest);
        System.out.printf("  Average Case (random ID):            %10.3f ms%n", binAvg);
        System.out.printf("  Worst Case (ID not found):           %10.3f ms%n", binWorst);
        System.out.println();
        System.out.printf("PERFORMANCE IMPROVEMENT: Binary search is ~%.0fx faster on average%n",
                improvement);
        System.out.println();
        System.out.printf("HYBRID NAME SEARCH:%n");
        System.out.printf("  Average search time: %10.3f ms%n", hybridSearchTime);
        System.out.printf("  Average insert time: %10.3f ms%n", hybridInsertTime);
        System.out.println("================================================================");
    }

    // -----------------------------------------------------------------------
    // Dataset generation
    // -----------------------------------------------------------------------

    /**
     * Generates an array of {@code count} products with unique, randomly chosen
     * product IDs in the range [1, MAX_ID].
     *
     * @param count number of products to generate
     * @return array of Product objects (unsorted)
     */
    static Product[] generateProducts(int count) {
        Random rng = new Random(42);            // fixed seed for reproducibility
        boolean[] usedIds = new boolean[MAX_ID + 1];
        Product[] products = new Product[count];

        for (int i = 0; i < count; i++) {
            int id;
            do {
                id = rng.nextInt(MAX_ID) + 1;
            } while (usedIds[id]);
            usedIds[id] = true;

            String name     = "Product-" + id;
            String category = CATEGORIES[rng.nextInt(CATEGORIES.length)];
            double price    = Math.round((rng.nextDouble() * 999 + 1) * 100.0) / 100.0;
            int    stock    = rng.nextInt(500);

            products[i] = new Product(id, name, category, price, stock);
        }
        return products;
    }

    // -----------------------------------------------------------------------
    // Timing helpers
    // -----------------------------------------------------------------------

    /** Runs sequential search {@code REPETITIONS} times and returns average ms. */
    private static double measureSeqSearch(SearchAlgorithms s, Product[] arr, int id) {
        long total = 0;
        for (int r = 0; r < REPETITIONS; r++) {
            long start = System.nanoTime();
            s.sequentialSearchById(arr, id);
            total += System.nanoTime() - start;
        }
        return total / (double) REPETITIONS / 1_000_000.0;
    }

    /** Runs binary search {@code REPETITIONS} times and returns average ms. */
    private static double measureBinSearch(SearchAlgorithms s, Product[] arr, int id) {
        long total = 0;
        for (int r = 0; r < REPETITIONS; r++) {
            long start = System.nanoTime();
            s.binarySearchById(arr, id);
            total += System.nanoTime() - start;
        }
        return total / (double) REPETITIONS / 1_000_000.0;
    }

    /** Runs hybrid name search {@code REPETITIONS} times and returns average ms. */
    private static double measureHybridNameSearch(HybridSearchIndex idx, String name) {
        long total = 0;
        for (int r = 0; r < REPETITIONS; r++) {
            long start = System.nanoTime();
            idx.searchByName(name);
            total += System.nanoTime() - start;
        }
        return total / (double) REPETITIONS / 1_000_000.0;
    }

    /**
     * Adds a brand-new product to the index and measures the insertion time.
     * Uses an ID above MAX_ID so it is guaranteed to be unique.
     */
    private static double measureHybridInsert(HybridSearchIndex idx) {
        int newId = MAX_ID + 100;
        long total = 0;
        for (int r = 0; r < REPETITIONS; r++) {
            Product p = new Product(newId + r, "NewProduct-" + (newId + r),
                                    "Accessory", 29.99, 10);
            long start = System.nanoTime();
            idx.addProduct(p);
            total += System.nanoTime() - start;
        }
        return total / (double) REPETITIONS / 1_000_000.0;
    }
}
