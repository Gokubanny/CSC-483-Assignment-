package com.csc483.assignment.search;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Hybrid search strategy that combines:
 * <ol>
 *   <li>A <b>sorted array</b> of products (sorted by productId) enabling O(log n)
 *       binary search by ID.</li>
 *   <li>An <b>inverted name index</b> ({@code HashMap<String, List<Integer>>})
 *       mapping lower-cased product names to the list of their IDs, enabling
 *       sub-linear average-case name lookup.</li>
 * </ol>
 *
 * <h3>Complexity Analysis</h3>
 * <table border="1">
 *   <tr><th>Operation</th><th>Time Complexity</th><th>Space Complexity</th></tr>
 *   <tr><td>Search by ID (binary)</td><td>O(log n)</td><td>O(1)</td></tr>
 *   <tr><td>Search by name (hash)</td><td>O(1) average, O(n) worst</td><td>O(1)</td></tr>
 *   <tr><td>addProduct (sorted insert)</td><td>O(n) shift + O(1) hash update = O(n)</td><td>O(n) resize</td></tr>
 *   <tr><td>Build index from scratch</td><td>O(n log n) sort + O(n) hash build</td><td>O(n)</td></tr>
 * </table>
 *
 * <h3>Design Rationale</h3>
 * The sorted array guarantees O(log n) ID search. The HashMap provides average
 * O(1) name lookup without needing to sort by name. When a new product is added,
 * only a single insertion into both structures is needed, avoiding full rebuilds.
 *
 * @author  [Student Name]
 * @version 1.0
 */
public class HybridSearchIndex {

    /** Internal sorted storage; sorted ascending by productId. */
    private Product[] sortedProducts;

    /** Number of products actually stored (may be less than array capacity). */
    private int size;

    /**
     * Inverted name index: key = lower-cased product name,
     * value = list of productIds sharing that name.
     */
    private final Map<String, List<Integer>> nameIndex;

    /** Backing search engine (re-used for binary search). */
    private final SearchAlgorithms searcher;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    /**
     * Initialises the hybrid index from an existing (possibly unsorted) array
     * of products.
     *
     * <p>The constructor sorts the array by productId in O(n log n) and builds
     * the name index in O(n).
     *
     * @param products source array (must not be null; may be empty)
     */
    public HybridSearchIndex(Product[] products) {
        if (products == null) throw new IllegalArgumentException("products array must not be null");

        // Copy so we don't mutate the caller's array
        this.sortedProducts = Arrays.copyOf(products, products.length);
        this.size           = products.length;
        this.nameIndex      = new HashMap<>();
        this.searcher       = new SearchAlgorithms();

        // Sort by productId for binary search
        Arrays.sort(this.sortedProducts, 0, size);

        // Build name index
        for (int i = 0; i < size; i++) {
            indexByName(sortedProducts[i]);
        }
    }

    // -----------------------------------------------------------------------
    // Search methods
    // -----------------------------------------------------------------------

    /**
     * Searches for a product by its ID using binary search on the sorted array.
     *
     * <p><b>Time Complexity:</b> O(log n) worst case.
     *
     * @param targetId the product ID
     * @return the matching product, or {@code null} if not found
     */
    public Product searchById(int targetId) {
        return searcher.binarySearchById(sortedProducts, targetId);
    }

    /**
     * Searches for a product by name using the HashMap index.
     *
     * <p>The lookup first retrieves the list of matching IDs from the hash map
     * in O(1) average time, then does a binary search for the first ID found.
     *
     * <p><b>Time Complexity:</b> O(1) average (hash lookup + single binary search).
     *
     * @param targetName product name (case-insensitive)
     * @return the first matching product, or {@code null} if not found
     */
    public Product searchByName(String targetName) {
        if (targetName == null) return null;

        List<Integer> ids = nameIndex.get(targetName.toLowerCase());
        if (ids == null || ids.isEmpty()) return null;

        // Retrieve the first matching product via binary search
        return searcher.binarySearchById(sortedProducts, ids.get(0));
    }

    // -----------------------------------------------------------------------
    // Mutation
    // -----------------------------------------------------------------------

    /**
     * Adds a new product to both the sorted array and the name index.
     *
     * <p>The method finds the correct insertion position using binary search
     * (O(log n)), then shifts elements rightward to make room (O(n)), maintaining
     * sorted order. The name index is updated in O(1).
     *
     * <p><b>Time Complexity:</b> O(n) due to the array shift.
     * <b>Space Complexity:</b> O(n) if the backing array needs to be grown.
     *
     * @param newProduct the product to add (must not be null; ID must be unique)
     * @throws IllegalArgumentException if newProduct is null or its ID already exists
     */
    public void addProduct(Product newProduct) {
        if (newProduct == null) throw new IllegalArgumentException("newProduct must not be null");
        if (searcher.binarySearchById(sortedProducts, newProduct.getProductId()) != null)
            throw new IllegalArgumentException("Product with ID " + newProduct.getProductId() + " already exists");

        // Grow backing array if full
        if (size == sortedProducts.length) {
            sortedProducts = Arrays.copyOf(sortedProducts, Math.max(size * 2, 1));
        }

        // Find insertion position with binary search  – O(log n)
        int pos = findInsertionPoint(newProduct.getProductId());

        // Shift elements right to make room  – O(n)
        System.arraycopy(sortedProducts, pos, sortedProducts, pos + 1, size - pos);
        sortedProducts[pos] = newProduct;
        size++;

        // Update name index  – O(1) average
        indexByName(newProduct);
    }

    /**
     * Returns a snapshot of the sorted products array (defensive copy).
     *
     * @return sorted Product array of length {@code size()}
     */
    public Product[] getSortedProducts() {
        return Arrays.copyOf(sortedProducts, size);
    }

    /** @return number of products currently stored */
    public int size() { return size; }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Adds the product's name (lower-cased) and ID to the name index.
     */
    private void indexByName(Product p) {
        String key = p.getProductName().toLowerCase();
        nameIndex.computeIfAbsent(key, k -> new ArrayList<>()).add(p.getProductId());
    }

    /**
     * Returns the index at which {@code targetId} should be inserted to keep
     * the array sorted (similar to {@code Arrays.binarySearch} but always
     * returns a valid insertion point rather than a negative encoded value).
     */
    private int findInsertionPoint(int targetId) {
        int low = 0, high = size;
        while (low < high) {
            int mid = low + (high - low) / 2;
            if (sortedProducts[mid].getProductId() < targetId) {
                low = mid + 1;
            } else {
                high = mid;
            }
        }
        return low;
    }
}
