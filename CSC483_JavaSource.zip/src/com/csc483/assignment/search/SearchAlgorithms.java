package com.csc483.assignment.search;

/**
 * Provides sequential and binary search methods for arrays of {@link Product}.
 *
 * <p><b>Complexity summary:</b>
 * <ul>
 *   <li>Sequential search by ID  – O(1) best, O(n) average, O(n) worst</li>
 *   <li>Binary search by ID      – O(1) best, O(log n) average, O(log n) worst</li>
 *   <li>Sequential search by name – O(1) best, O(n) average, O(n) worst</li>
 * </ul>
 *
 * @author  [Student Name]
 * @version 1.0
 */
public class SearchAlgorithms {

    // -----------------------------------------------------------------------
    // Comparison counters (package-private for testing)
    // -----------------------------------------------------------------------

    /** Number of comparisons made during the most recent search call. */
    private long lastComparisonCount = 0;

    /** @return comparisons made during the last call to any search method */
    public long getLastComparisonCount() { return lastComparisonCount; }

    // -----------------------------------------------------------------------
    // Sequential Search by ID  – O(n)
    // -----------------------------------------------------------------------

    /**
     * Searches for a product with the given ID using linear/sequential search.
     *
     * <p>The array does <em>not</em> need to be sorted. Each element is examined
     * in turn until a match is found or the end of the array is reached.
     *
     * <p><b>Time Complexity:</b>
     * <ul>
     *   <li>Best case    – O(1)  : target is at index 0</li>
     *   <li>Average case – O(n/2): target is at a random position</li>
     *   <li>Worst case   – O(n)  : target not present or at last index</li>
     * </ul>
     * <b>Space Complexity:</b> O(1) – only a few local variables
     *
     * @param products array of Product objects (may be unsorted, may be null)
     * @param targetId the product ID to search for
     * @return the matching {@link Product}, or {@code null} if not found
     */
    public Product sequentialSearchById(Product[] products, int targetId) {
        lastComparisonCount = 0;

        if (products == null) return null;

        for (Product product : products) {
            lastComparisonCount++;               // one comparison per iteration
            if (product != null && product.getProductId() == targetId) {
                return product;                  // found – return immediately
            }
        }
        return null;                             // not found
    }

    // -----------------------------------------------------------------------
    // Binary Search by ID  – O(log n)
    // -----------------------------------------------------------------------

    /**
     * Searches for a product with the given ID using binary search.
     *
     * <p><b>Pre-condition:</b> {@code products} must be sorted in ascending order
     * by {@code productId}. If the array is unsorted, results are undefined.
     *
     * <p><b>Time Complexity:</b>
     * <ul>
     *   <li>Best case    – O(1)     : target is exactly at the middle index</li>
     *   <li>Average case – O(log n) : target is at an arbitrary sorted position</li>
     *   <li>Worst case   – O(log n) : target not present (floor(log2 n) + 1 comparisons)</li>
     * </ul>
     * <b>Space Complexity:</b> O(1) – iterative implementation uses no call stack
     *
     * @param products array of Product objects sorted ascending by productId
     * @param targetId the product ID to search for
     * @return the matching {@link Product}, or {@code null} if not found
     */
    public Product binarySearchById(Product[] products, int targetId) {
        lastComparisonCount = 0;

        if (products == null || products.length == 0) return null;

        int low  = 0;
        int high = products.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;   // avoids integer overflow
            lastComparisonCount++;

            if (products[mid] == null) {
                // skip null entries (treat as "less than" target)
                high = mid - 1;
                continue;
            }

            int midId = products[mid].getProductId();

            if (midId == targetId) {
                return products[mid];            // found
            } else if (midId < targetId) {
                low  = mid + 1;                  // target is in upper half
            } else {
                high = mid - 1;                  // target is in lower half
            }
        }
        return null;                             // not found
    }

    // -----------------------------------------------------------------------
    // Sequential Search by Name  – O(n)
    // -----------------------------------------------------------------------

    /**
     * Searches for a product with the given name using sequential search.
     *
     * <p>Since product names are not kept in sorted order, binary search cannot
     * be applied here. The comparison is <em>case-insensitive</em>.
     *
     * <p><b>Time Complexity:</b> O(n) worst and average case.
     * <b>Space Complexity:</b> O(1).
     *
     * @param products   array of Product objects (order irrelevant)
     * @param targetName the product name to search for (case-insensitive)
     * @return the first matching {@link Product}, or {@code null} if not found
     */
    public Product searchByName(Product[] products, String targetName) {
        lastComparisonCount = 0;

        if (products == null || targetName == null) return null;

        for (Product product : products) {
            lastComparisonCount++;
            if (product != null && product.getProductName().equalsIgnoreCase(targetName)) {
                return product;
            }
        }
        return null;
    }
}
