# CSC483-Algorithms-Assignment-[MATNO]

**Course:** CSC 483.1 – Algorithm Analysis and Design  
**University:** University of Port Harcourt, Faculty of Computing  
**Academic Session:** 2025/2026, First Semester  

---

## Project Structure

```
src/
└── com/csc483/assignment/
    ├── search/
    │   ├── Product.java             # Q1 – Product data model
    │   ├── SearchAlgorithms.java    # Q1 – Sequential & binary search
    │   ├── HybridSearchIndex.java   # Q1 – Hybrid name+ID search index
    │   └── TechMartMain.java        # Q1 – Benchmark driver (main entry point)
    ├── sorting/
    │   ├── SortingAlgorithms.java   # Q2 – Insertion, Merge, Quick Sort
    │   └── BenchmarkRunner.java     # Q2 – Empirical analysis driver
    └── test/
        ├── SearchTest.java          # JUnit 5 tests for Q1
        └── SortingTest.java         # JUnit 5 tests for Q2
datasets/
    ├── sample_products.csv          # Sample 100-row product dataset
    └── sorting_results.csv          # Benchmark output snapshot
```

---

## Dependencies

| Dependency      | Version | Purpose               |
|-----------------|---------|-----------------------|
| Java JDK        | 11+     | Language runtime      |
| JUnit Jupiter   | 5.9+    | Unit testing          |
| JUnit Platform  | 1.9+    | Test runner           |

---

## Compilation Instructions

### Option A – Manual (no build tool)

```bash
# 1. Create output directory
mkdir -p out

# 2. Compile all source files
javac -d out \
  src/com/csc483/assignment/search/*.java \
  src/com/csc483/assignment/sorting/*.java

# 3. Compile tests (requires JUnit 5 jars on classpath)
javac -cp out:lib/junit-jupiter-api-5.9.0.jar -d out \
  src/com/csc483/assignment/test/*.java
```

### Option B – IntelliJ IDEA
1. Open the project root as a new project.
2. Mark `src/` as the Sources Root.
3. Add JUnit 5 via **File → Project Structure → Libraries**.
4. Use **Build → Build Project**.

---

## Execution Instructions

### Run Q1 – TechMart Search Benchmark

```bash
java -cp out com.csc483.assignment.search.TechMartMain
```

Expected output: formatted table comparing sequential vs binary search
performance over 100,000 products.

### Run Q2 – Sorting Algorithm Benchmark

```bash
java -cp out com.csc483.assignment.sorting.BenchmarkRunner
```

Expected output: comparative table of Insertion, Merge, and Quick Sort
across five dataset types and four input sizes, plus statistical analysis.

### Run Tests

```bash
# Using JUnit Console Launcher (download from https://junit.org)
java -cp out:lib/* \
  org.junit.platform.console.standalone.ConsoleLauncher \
  --scan-classpath
```

---

## Sample Usage

```java
// Create a sorted product array
Product[] products = TechMartMain.generateProducts(1000);
Arrays.sort(products);   // sort by productId

// Search by ID
SearchAlgorithms searcher = new SearchAlgorithms();
Product found = searcher.binarySearchById(products, 12345);

// Hybrid index
HybridSearchIndex index = new HybridSearchIndex(products);
Product byName = index.searchByName("Product-12345");
index.addProduct(new Product(200001, "NewItem", "Laptop", 999.99, 5));
```

---

## Known Limitations

- `TechMartMain` uses a fixed random seed (42) for reproducibility; real
  benchmarks should use multiple seeds.
- Quick Sort degrades to O(n²) on adversarial inputs despite median-of-three
  pivot; Heap Sort is safer for guaranteed worst-case.
- The `addProduct` method in `HybridSearchIndex` is O(n) due to array shifting;
  a balanced BST or skip list would give O(log n) insertion.
